from .instabot import InstaBot

__all__ = ['InstaBot']
